
let MENU = document.querySelector('.MENU');

document.querySelector('#menu-btn').onclick = () =>{
    MENU.classList.toggle('active');
    
}